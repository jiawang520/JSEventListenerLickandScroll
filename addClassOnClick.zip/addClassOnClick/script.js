const buttonOne = document.querySelector(".button-one");
const buttonTwo = document.querySelector(".button-two");
const buttonThree = document.querySelector(".button-three");
const buttonFour = document.querySelector(".button-four");
const buttonFive = document.querySelector(".button-five");
const buttonSix = document.querySelector(".button-six");
const buttonSeven = document.querySelector(".button-seven");
const buttonEight = document.querySelector(".button-eight");

const boxOne = document.querySelector(".box-one");
const boxTwo = document.querySelector(".box-two");
const boxThree = document.querySelector(".box-three");
const boxFour = document.querySelector(".box-four");
const boxFive = document.querySelector(".box-five");
const boxSix = document.querySelector(".box-six");
const boxSeven = document.querySelector(".box-seven");
const boxEight = document.querySelector(".box-eight");

const allButtons = document.querySelectorAll(".button");
const allBoxes = document.querySelectorAll(".box");

// buttonOne.addEventListener("click", function() {
//     boxOne.classList.toggle("boxTrigger");
// });

// function addClassOnClick(elementToBeClicked, elementToHaveClassAdded, classNameToBeAdded) {
//     if (!classNameToBeAdded) {
//         // classNameToBeAdded
//     }
// }

// class addClass {
//     constructor(elementToBeClicked, elementToHaveClassAdded, classNameToBeAdded) {
//         this.elementToBeClicked = elementToBeClicked;
//         this.elementToHaveClassAdded = elementToHaveClassAdded;
//         this.classNameToBeAdded = classNameToBeAdded;
//     };
//     addClassOnClick() {
//         document.querySelector(this.elementToBeClicked).addEventListener("click", function() {
//             document.querySelector(this.elementToHaveClassAdded).classList.toggle(this.classNameToBeAdded);
//             console.log(this.elementToBeClicked);
//         });
//     };
// }

function addClassOnClick(elementToBeClicked, elementToHaveClassAdded, classNameToBeAdded) {
    elementToBeClicked.addEventListener("click", function() {
        elementToHaveClassAdded.classList.toggle(classNameToBeAdded);
        // console.log(classNameToBeAdded);
    });
};

addClassOnClick(buttonOne, boxOne, "Trigger");
addClassOnClick(buttonTwo, boxTwo, "Trigger");
addClassOnClick(buttonThree, boxThree, "Trigger");
addClassOnClick(buttonFour, boxFour, "Trigger");
addClassOnClick(buttonFive, boxFive, "Trigger");
addClassOnClick(buttonSix, boxSix, "Trigger");
addClassOnClick(buttonSeven, boxSeven, "Trigger");
addClassOnClick(buttonEight, boxEight, "Trigger");

// let newClass = new addClass(buttonOne, boxOne, "boxTrigger");
// addClassOnClick(buttonOne, boxOne, "boxTrigger");