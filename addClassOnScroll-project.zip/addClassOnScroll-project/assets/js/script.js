const targetOne = document.querySelector('.target-one');
const targetTwo = document.querySelector('.target-two');

// https://www.w3schools.com/jsref/met_element_getboundingclientrect.asp
// Hint: you will probably want to use top or y and height.

//https://www.w3schools.com/jsref/event_onscroll.asp\
// Use add addEventListener with "scroll"

// https://www.w3schools.com/jsref/prop_win_innerheight.asp

let windowHeight = window.innerHeight;
window.addEventListener("resize", function() {
    windowHeight = window.innerHeight;
});

// Complete the function called addClassOnScroll. It two arguments. 
// The first argument is an HTML element. The second is a class name. 
// See commented out function calls below and the assets/css/style.css file for clues on how this will work. 
// The pink section elements: targetOne and targetTwo should turn red soon (at any point) after they scroll onto the screen by adding the class .
// trigger to them. For a challenge, remove the class .trigger, right before they scroll off the top of the screen, and then add the class as the screen scrolls down.

function addClassOnScroll(ele, classNameNew) {
    window.addEventListener("scroll", function() {
        let pinkSectionPosition = ele.getBoundingClientRect();
        let h = pinkSectionPosition.height;
        let y = pinkSectionPosition.top;
        let b = pinkSectionPosition.bottom;
        let yvar = pinkSectionPosition.y;

        // alert(y);
        this.console.log(h + ", " + y + ", " + b + ", top minus Height = " + (y - h) + "windows height =" + windowHeight);
        if ((y - h) <= h) {
            // ele.classList.toggle(className);
            // ele.classList.toggle(className);
            ele.className = classNameNew;
        }
        if (b < 55) {
            ele.className = "pink";
        }
    });

    // let pinkSectionPosition = ele.getBoundingClientRect();
    // let x = pinkSectionPosition.left;
    // let y = pinkSectionPosition.top;
    // alert(x + ", " + y);
    // ele.classList.toggle(className);

}

addClassOnScroll(targetOne, "trigger");

addClassOnScroll(targetTwo, "trigger");